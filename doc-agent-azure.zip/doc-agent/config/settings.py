"""
Central Settings — Azure-Native Configuration

All secrets are sourced from Azure Key Vault in production.
The Container App's Managed Identity pulls them at runtime —
no passwords, no connection strings in code or config files.

Azure service mapping:
  azure_storage_*        → Azure Blob Storage (document ingestion)
  service_bus_*          → Azure Service Bus (reliable queue)
  azure_openai_*         → Azure OpenAI / GPT-4o (classification)
  doc_intelligence_*     → Azure Document Intelligence (extraction)
  app_insights_*         → Azure Application Insights (observability)

Local dev (LOCAL_DEV=true):
  All Azure services are stubbed — no credentials needed.
  Swap to LOCAL_DEV=false + real endpoints to go live on Azure.
"""
import os
from dataclasses import dataclass, field


@dataclass
class Settings:

    # ── Azure Blob Storage ────────────────────────────────────────────────────
    # Layer 1: All inbound documents land here first
    # Azure service: Storage Account > Blob Container "documents"
    # Trigger: Azure Event Grid fires on every new blob upload
    azure_storage_connection_string: str = field(
        default_factory=lambda: os.getenv(
            "AZURE_STORAGE_CONNECTION_STRING", "UseDevelopmentStorage=true"
        )
    )
    azure_storage_container: str = field(
        default_factory=lambda: os.getenv("AZURE_STORAGE_CONTAINER", "documents")
    )

    # ── Azure Service Bus ─────────────────────────────────────────────────────
    # Layer 1: Decouples ingestion from processing
    # Provides: retry logic, dead-letter queue, exactly-once delivery
    # Azure service: Service Bus Namespace > Queue "document-processing"
    service_bus_connection_string: str = field(
        default_factory=lambda: os.getenv("SERVICE_BUS_CONNECTION_STRING", "")
    )
    service_bus_queue: str = field(
        default_factory=lambda: os.getenv(
            "SERVICE_BUS_QUEUE", "document-processing"
        )
    )

    # ── Azure OpenAI (GPT-4o) ─────────────────────────────────────────────────
    # Layer 2: Powers the Classifier Agent
    # Azure service: Azure OpenAI > Deployment "gpt-4o"
    # Key stored in: Azure Key Vault > Secret "openai-key"
    # Access via: Container App Managed Identity (no hardcoded keys)
    azure_openai_endpoint: str = field(
        default_factory=lambda: os.getenv("AZURE_OPENAI_ENDPOINT", "")
    )
    azure_openai_key: str = field(
        default_factory=lambda: os.getenv("AZURE_OPENAI_KEY", "")
    )
    azure_openai_deployment: str = field(
        default_factory=lambda: os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o")
    )

    # ── Azure Document Intelligence ───────────────────────────────────────────
    # Layer 2: Powers the Extractor Agent for PDFs and structured docs
    # Azure service: Cognitive Services > Document Intelligence
    # Pre-built models: prebuilt-invoice, prebuilt-document
    # Key stored in: Azure Key Vault > Secret "doc-intelligence-key"
    doc_intelligence_endpoint: str = field(
        default_factory=lambda: os.getenv("DOC_INTELLIGENCE_ENDPOINT", "")
    )
    doc_intelligence_key: str = field(
        default_factory=lambda: os.getenv("DOC_INTELLIGENCE_KEY", "")
    )

    # ── Azure Cosmos DB ───────────────────────────────────────────────────────
    # Layer 5: Immutable audit trail — every document action persisted
    # Azure service: Cosmos DB > Database "doc-agent-db" > Container "audit-trail"
    # Partitioned by doc_type for efficient querying
    cosmos_endpoint: str = field(
        default_factory=lambda: os.getenv("COSMOS_ENDPOINT", "")
    )
    cosmos_key: str = field(
        default_factory=lambda: os.getenv("COSMOS_KEY", "")
    )

    # ── Azure Application Insights ────────────────────────────────────────────
    # Layer 5: Structured telemetry, distributed tracing, alerting
    # Azure service: Application Insights > Connected to Log Analytics Workspace
    # Dashboard: Azure Monitor Workbook (confidence scores, escalation rates, SLA)
    app_insights_connection_string: str = field(
        default_factory=lambda: os.getenv(
            "APPLICATIONINSIGHTS_CONNECTION_STRING", ""
        )
    )

    # ── Pipeline Configuration ────────────────────────────────────────────────
    # Confidence threshold: below this → escalate to human review queue
    # Tunable per environment — prod may use 0.85, staging 0.75
    confidence_threshold: float = field(
        default_factory=lambda: float(
            os.getenv("CONFIDENCE_THRESHOLD", "0.80")
        )
    )

    # ── Local Dev Mode ────────────────────────────────────────────────────────
    # true  → keyword heuristics, in-memory queue, stub connectors
    # false → real Azure OpenAI, Document Intelligence, Service Bus, Cosmos DB
    # Controlled by environment variable — same codebase, different behaviour
    local_dev: bool = field(
        default_factory=lambda: os.getenv("LOCAL_DEV", "true").lower() == "true"
    )


settings = Settings()
